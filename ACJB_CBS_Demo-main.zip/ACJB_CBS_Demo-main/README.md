# GitHub Codespaces ♥️ Django

Welcome to your shiny new Codespace running Django! We've got everything fired up and running for you to explore Django.

You've got a blank canvas to work on from a git perspective as well. There's a single initial commit with what you're seeing right now - where you go from here is up to you!

# Repo Note

- SQL Injection Vuln. Website
- users.sql contains sample data
- using db.sqlite3 from django for users
- Cred: (alice@example.com, pass)
- Regex for Leak, {' OR 1=1; --}

### Steps for Leak

- Username any@any.com (CSS Checked)
- Password {regex}